from machine import Pin, I2C
import network
import time
from picozero import pico_temp_sensor, pico_led
from blynklib import Blynk


def connect_to_internet(ssid, password):
    # Pass in string arguments for ssid and password

    # Just making our internet connection
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid, password)

    # Wait for connect or fail
    max_wait = 10
    while max_wait > 0:
        if wlan.status() < 0 or wlan.status() >= 3:
            break
        max_wait -= 1
        print('waiting for connection...')
        time.sleep(1)
    # Handle connection error
    if wlan.status() != 3:
        print(wlan.status())
        raise RuntimeError('network connection failed')
    else:
        print('connected')
        print(wlan.status())
        status = wlan.ifconfig()


connect_to_internet("wewksham", "9ee87eww65ewewe4fsdfdf21")

BLYNK = Blynk("_nhXAfm2-SDS8sdsdmJZ2kaPwqw")

led = machine.Pin("LED", machine.Pin.OUT)

@BLYNK.on("V0")
def turn_on_led(value):
    if int(value[0]) == 1:
        led.on()
    else:
        led.off()

while True:
    temperature = pico_temp_sensor.temp
    # Print sensor data to console
    BLYNK.virtual_write(7, temperature)
    BLYNK.run()
    time.sleep(1)

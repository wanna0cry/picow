# rpi-peppe8o

Scripts available to use external devices.
Tutorials and description available from https://peppe8o.com
